// Example2.cpp

/* This program calls the Artistic Style GUI formatter (AStyleMain)
 * to format the astyle source files in a test-c directory.
 */

#include "AStyleInterface.h"

#include <string.h>         // need both string and string.h for GCC
#include <stdlib.h>
#include <fstream>
#include <iostream>
using namespace std;

// function declarations
void error(const char *why, const char* what = "");
string getProjectDirectory(string& fileName);
char* getText(string& filePath);
void  setText(const char* textOut, string& filePathStr);
void setOptionValues(AStyleInterface& as);


int main(int, char **)
{   // options to pass to AStyle
    string fileName[] = { "AStyleDev/test-c/ASBeautifier.cpp",
                          "AStyleDev/test-c/ASFormatter.cpp" ,
                          "AStyleDev/test-c/astyle.h"
                        };
    size_t arraySize = sizeof(fileName) / sizeof(fileName[0]);

    // create an object
    AStyleInterface astyle;

    // set test values for the options
    astyle.setTestOptions();

    // get Artistic Style version
    char* version = AStyleGetVersion();
    cout << "Example2 C++ - AStyle " << version << endl;

    // process the input files
    for (size_t i = 0; i < arraySize; i++)
    {   // get the text to format
        string filePath = getProjectDirectory(fileName[i]);
        char* textIn = getText(filePath);

        // call the Artistic Style formatting function
        char* textOut = astyle.formatSource(textIn, filePath);

        // NULL pointer is an error - restore the original file
        // an error message has been displayed by the error handler
        if (textOut == NULL)
        {   cout << "Cannot format " << filePath << endl;
            return 0;
        }

        // return the formatted text
        cout << "Formatted " << fileName[i] << endl;
        setText(textOut, filePath);

        // must delete the temporary buffers
        delete [] textIn;
        delete [] textOut;
    }
#ifdef __MINGW32__
    system("pause");
#endif
}

// Error message function for this example
void error(const char *why, const char* what)
{   cout << why << ' ' << what << endl;
    cout << "The program has terminated!" << endl;
    exit(1);
}

// get the complete filepath for the filename
// the directory path may need to be changed
string getProjectDirectory(string& fileName)
{
#ifdef _WIN32
    char* homeDirectory = getenv("USERPROFILE");
#else
    char* homeDirectory = getenv("HOME");
#endif
    if (!homeDirectory)
        error("Cannot find HOME directory");
    string projectPath = string(homeDirectory) + "/Projects/" + fileName;
    return projectPath;
}

// get the text to be formatted
// usually the text would be obtained from an edit control
char* getText(string& filePath)
{   // open input file
    ifstream in(filePath.c_str());
    if (!in)
        error("Cannot open input file", filePath.c_str());

    // get length of buffer
    in.seekg(0, ifstream::end);
    size_t bufferSizeIn = static_cast<size_t>(in.tellg());
    in.seekg(0, ifstream::beg);

    // allocate memory
    char* bufferIn = new(nothrow) char [bufferSizeIn];
    if (bufferIn == NULL)
    {   in.close();
        error("Memory allocation failure on input");
    }

    // read data as a block
    in.read(bufferIn, bufferSizeIn);
    in.close();

    // get actual size - will be smaller than buffer size
    size_t textSizeIn = static_cast<size_t>(in.gcount());
    bufferIn[textSizeIn-1] = '\0';

    return bufferIn;
}

// return the formatted text
// usually the text would be returned to an edit control
void setText(const char* textOut, string& filePathStr)
{   // create a backup file
    const char* filePath = filePathStr.c_str();
    string origfilePathStr = filePathStr + ".orig";
    const char* origfilePath = origfilePathStr.c_str();
    remove(origfilePath);              // remove a pre-existing file

    if (rename(filePath, origfilePath) < 0)
        error("Cannot open input file", filePath);

    // open the output file
    ofstream out(filePath);
    if (!out)
        error("Cannot open output file", filePath);

    // write the text
    int textSizeOut = strlen(textOut);
    out.write(textOut, textSizeOut);
    out.close();
}
